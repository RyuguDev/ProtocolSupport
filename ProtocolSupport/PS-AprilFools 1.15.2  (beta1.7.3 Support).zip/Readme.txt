protocolsupport April fools version from xIcee for 1.15.2 to beta1.7.3 testing grounds. 
it has to be ran from Java 14 https://jdk.java.net/archive/

Swords seem to do the correct amount of damage, at least as long as the sheep I tried to hit didn't have 2hp before using a wooden sword on it 

this was only really a test and is nowhere near usable for actual play 

